
  # Personalized Financial Starter Kit

  This is a code bundle for Personalized Financial Starter Kit. The original project is available at https://www.figma.com/design/kPoAH5qHfKdKLLT71mEqlg/Personalized-Financial-Starter-Kit.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  